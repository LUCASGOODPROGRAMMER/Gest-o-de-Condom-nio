﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeGestaoDoCondominio.RegrasDeCondominio
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public string Genero { get; set; }

        public string DataNascimento { get; set; }
        public int CPF { get; set; }
        public double Renda { get; set; }
        public string Titulo { get; set; }
    }
}
