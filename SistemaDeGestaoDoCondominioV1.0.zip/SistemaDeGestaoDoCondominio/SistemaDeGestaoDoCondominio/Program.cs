﻿using SistemaDeGestaoDoCondominio.RegrasDeCondominio;

List<Casa> casas = new List<Casa>();
List<Pessoa> pessoas = new List<Pessoa>();

int continuar = 0;

void CadastrarCasa()
{
    Console.WriteLine("_______________CADASTRO DE CASA_______________\n\n");

}
while (continuar == 0)
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("_______________CONDOMINIO DO TRAFICO_______________\n\n");
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine("0 - Encerrar o Programa");
    Console.WriteLine("1 - Cadastar Casa");
    Console.WriteLine("2 - Cadstrar Morador em uma casa");
    Console.WriteLine("3 - Consultar Morador Por Nome");
    Console.WriteLine("4 - Filtrar Moradores Por Nome");
    Console.WriteLine("5 - Filtrar Moradores Por Salário");
    Console.WriteLine("6 - Filtar Moradores Por Tipo De Casa");
    Console.WriteLine("7 - Percentual De Moradores Por Casa");
    Console.WriteLine("8 - Todos Os Moradores Titular\n");

    Console.Write("Insira O Código Correspondente à Sua Escolha: ");
    Console.ForegroundColor = ConsoleColor.Green;
    int resposta = Convert.ToInt16(Console.ReadLine());

    switch (resposta)
    {
        case 0: 
        {              
           break;         
        }
        case 1: 
            { 


                break; 
            }
        case 2: { break; }
        case 3: { break; }
        case 4: { break; }
        case 5: { break; }
        case 6: { break; }
        case 7: { break; }
        case 8: { break; }
    }
}

