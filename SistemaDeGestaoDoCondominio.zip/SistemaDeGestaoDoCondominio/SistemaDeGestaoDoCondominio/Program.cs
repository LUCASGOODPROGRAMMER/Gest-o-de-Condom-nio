﻿using SistemaDeGestaoDoCondominio.RegrasDeCondominio;

List<Casa> listaCasas = new List<Casa>();


int continuar = 0;

void CadastrarCasa()
{
    while (continuar != 1)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("_______________CADASTRO DE CASA_______________\n\n");
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("Informe o código da casa - ");
        var numeroCasa = Convert.ToInt32(Console.ReadLine());

        Console.Write("\nINFORME O TIPO DA CASA:\n" +
            "TIPO DA CASA    | $PREÇO$ \n" +
            "----------------|---------\n" +
            "1 - BASICA      | $300.000\n" +
            "2 - PADRAO      | $500.000\n" +
            "3 - ALTO PADRAO | $700.000\n");

        Console.Write("Insira O Código Correspondente à Sua Escolha: ");
        var tipoCasa = Console.ReadLine();

        if (tipoCasa == "1") tipoCasa = "basica";
        else if (tipoCasa == "2") tipoCasa = "padrao";
        else tipoCasa = "altopadrao";

        Console.Write("Informe O Primeiro Veiculo Que esta na casa: ");
        var descricaoVeiculo1 = Console.ReadLine();
        Console.Write("Informe O Segundo Veiculo Que esta na casa: ");
        var descricaoVeiculo2 = Console.ReadLine();

        Casa dadosCasa = new Casa(numeroCasa, tipoCasa, descricaoVeiculo1, descricaoVeiculo2);
        listaCasas.Add(dadosCasa);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("CASA CADASTRADA COM SUCESSO");
        Console.WriteLine($"CODIGO DA CASA: {numeroCasa}\nTIPO DA CASA: {tipoCasa}\n" +
            $"PRIMEIRO VEICULO: {descricaoVeiculo1}\n SEGUNDO VEICULO: {descricaoVeiculo2}\n\n");

        Console.WriteLine("DESEJA CONTINUAR CADASTRANDO CASA? S/N");
        string condicao = Console.ReadLine().ToUpper();
        if (condicao == "N") continuar = 1;
    }
    continuar = 0;
   

}
Casa SelecionarCasa()
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("_______________SELECIONAR CASA_______________\n");
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine("_______________CASAS DISPONIVEIS_______________");
    //colocar alguma função aqui que mostre casas com menos de 7 moradores

    Console.Write("Informe O codigo Da Casa: ");
    var numeroCasa = Convert.ToInt32(Console.ReadLine());
    Console.ForegroundColor = ConsoleColor.Green;

    Casa procurar = listaCasas.Where(achar => achar.NumeroCasa == numeroCasa);



}

while (continuar == 0)
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("_______________CONDOMINIO DO TRAFICO_______________\n\n");
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine("0 - Encerrar o Programa");
    Console.WriteLine("1 - Cadastar Casa");
    Console.WriteLine("2 - Cadastrar Morador em uma casa");
    Console.WriteLine("3 - Consultar Morador Por Nome");
    Console.WriteLine("4 - Filtrar Moradores Por Nome");
    Console.WriteLine("5 - Filtrar Moradores Por Salário");
    Console.WriteLine("6 - Filtar Moradores Por Tipo De Casa");
    Console.WriteLine("7 - Percentual De Moradores Por Casa");
    Console.WriteLine("8 - Todos Os Moradores Titular");
    Console.WriteLine("9 - Consultar Morador Por Casa\n");

    Console.Write("Insira O Código Correspondente à Sua Escolha: ");
    Console.ForegroundColor = ConsoleColor.Green;
    int resposta = Convert.ToInt16(Console.ReadLine());

    switch (resposta)
    {
        case 0: 
        {              
           break;         
        }
        case 1: 
            {
                CadastrarCasa();
               break; 
            }
        case 2: 
            { 

                break; 
            }
        case 3: { break; }
        case 4: { break; }
        case 5: { break; }
        case 6: { break; }
        case 7: { break; }
        case 8: { break; }
    }
}

