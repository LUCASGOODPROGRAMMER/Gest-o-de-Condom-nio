﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeGestaoDoCondominio.RegrasDeCondominio
{
    public class Casa
    {
        /*Número da casa
        Tipo da casa (Básica, Padrão, Alto Padrão)
         Descrição do veículo 1
         Descrição do veículo 2
         Valor da casa (calculado automaticamente com base no tipo)
        Lista de moradores: Deve ser uma lista (List<Pessoa>) contendo os moradores cadastrados na casa.
       Valor do condomínio (calculado pelo sistema) */
       
        public string NumeroCasa { get; set; }
        public string TipoCasa { get; set; }
        public string DescricaoVeiculo1 { get; set; }

        public string DescricaoVeiculo2 { get; set; }
        public double ValorCasa { get; set; }
        public string MoradoresNaCasa { get; set; }

        public double ValorCondominio { get; set; } //Valor do Condomínio = (Número de moradores) * (Valor da casa) * 0,1%

        public List<Pessoa> MoradoresCadastrados { get; set; }
        public Casa(string numeroCasa, string tipoCasa, string descricaoVeiculo1, string descricaoVeiculo2) 
        {
            this.NumeroCasa = numeroCasa;
            this.TipoCasa = tipoCasa;
            this.DescricaoVeiculo1 = descricaoVeiculo1;
            this.DescricaoVeiculo2 = descricaoVeiculo2;
          

            MoradoresCadastrados = new List<Pessoa>();
        }
        public double ValorDaCasa()
        {
            
            if (TipoCasa.ToUpper() == "BASICA") ValorCasa = 300.000;
            else if (TipoCasa.ToUpper() == "PADRAO") ValorCasa = 500.000;
            else ValorCasa = 700.000;

            return ValorCasa;
        }
        public double ValorDoCondominio()
        {
            return MoradoresNaCasa.Count() * ValorCasa /100 * 0.1;
        }
        public void RetornarCondominio()
        {
            Console.WriteLine($"Valor do  Condominio = {ValorDoCondominio()}");
            Console.WriteLine($"Quantidade de Moradores = {MoradoresNaCasa.Count()}" );
        }
        public void CadastrarMorador()
        {
            int continuar = 1;
            while (continuar != 0)
            {

            }
        }
        public void CadastrarMorador()
        {            
            Pessoa pessoa = new Pessoa();

            Console.Write("Informe seu nome: ");
            pessoa.Nome = Console.ReadLine();

            Console.Write("In")


        }

    }
    
    

}
